function sendPeople() {

}
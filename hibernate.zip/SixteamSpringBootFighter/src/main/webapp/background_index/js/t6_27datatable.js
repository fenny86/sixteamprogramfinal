window.addEventListener('DOMContentLoaded', event => {
    // Simple-DataTables
    // https://github.com/fiduswriter/Simple-DataTables/wiki

    const datatablesSimplet6_27= document.getElementById('datatablesSimplet6_27');
    if (datatablesSimplet6_27) {
        new simpleDatatables.DataTable(datatablesSimplet6_27);
    }
});

package sixteam.t6_23.model.matadata;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MataDataRepository extends JpaRepository<MataDataBean, Integer> {

//	public List<MataDataBean> findByUsername();
}

package sixteam.t6_23.model.matchsuccessdata;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MatchSuccessDataRepository extends JpaRepository<MatchSuccessDataBean, Integer> {
	
	

}

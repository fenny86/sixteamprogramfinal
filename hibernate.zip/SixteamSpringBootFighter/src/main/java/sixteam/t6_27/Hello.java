package sixteam.t6_27;

public class Hello {

	public static void main(String[] args) {
		System.out.println("hello");
	}

}
